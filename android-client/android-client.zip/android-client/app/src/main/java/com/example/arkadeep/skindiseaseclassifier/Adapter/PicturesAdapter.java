package com.example.arkadeep.skindiseaseclassifier.Adapter;

public class PicturesAdapter extends  {
}
